package com.wallet.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.Optional;

import org.aspectj.lang.annotation.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.wallet.model.User;

@RunWith(SpringRunner.class)

@ActiveProfiles({"userJpa"})
@ContextConfiguration(classes= {UserRepository.class})
@DataJpaTest
public class UserRepositoryTest {

	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private TransactionRepository transactionRepository;
	User user;
	
	
		
	
	@Test
	public void testSaveUser() {
		 user=getUser();
		User savedUser=entityManager.persist(user);
		User dbUser=userRepository.findByUsername(savedUser.getUsername());
		
		assertEquals(dbUser, savedUser);
	}
	@Test
	public void testUsernameAndPassword() {
		user=getUser();
		User dbUser=userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		assertEquals(dbUser, user);
	}
	@Test
	public void testUsernameAndPasswordAndAccNumber() {
		user=getUser();
		User dbUser=userRepository.findByUsernameAndPasswordAndAccountNumber(user.getUsername(), user.getPassword(), user.getAccountNumber());
		assertEquals(dbUser, user);
	}
	
	public User getUser() {
		User user=new User();
		user.setAccountBalance(0);
		user.setTime(LocalDateTime.now().toString());
		user.setAccountNumber("ACC");
		user.setEmail("aaa");
		user.setMobile("9001");
		user.setUsername("abc");
		user.setPassword("abcabc");
		user.setAccountType("savings");
		user.setUserId(12345);
		
		
		return user;
	}
}
