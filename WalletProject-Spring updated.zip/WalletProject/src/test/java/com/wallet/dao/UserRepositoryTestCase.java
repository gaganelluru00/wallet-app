package com.wallet.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.wallet.model.User;

@RunWith(SpringRunner.class)
@DataJpaTest
public class UserRepositoryTestCase {

	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private TransactionRepository transactionRepository;
	@Test
	void testSaveUser() {
		User user=getUser();
		User savedUser=entityManager.persist(user);
		User dbUser=userRepository.findByUsername(savedUser.getUsername());
		
		assertEquals(dbUser, savedUser);
	}
	public User getUser() {
		User user=new User();
		user.setAccountBalance(0);
		user.setTime(LocalDateTime.now().toString());
		user.setAccountNumber("ACC");
		user.setEmail("aaa");
		user.setMobile("9001");
		user.setUsername("abc");
		user.setPassword("abcabc");
		user.setAccountType("savings");
		
		
		return user;
	}


}
