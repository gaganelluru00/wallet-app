import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {  HttpclientService} from '../service/httpclient.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 navbarDisp:boolean;
  constructor(private rou:Router,public httpclientService:HttpclientService) { }

  ngOnInit(): void {
    this.navbarDisp=this.httpclientService.navbarDisplay;
  }
  openCreate(){
    this.rou.navigate(['transfer/add']);
  }
  openLogin(){
    this.rou.navigate(['transfer/login']);
  }
  closePop(){
    document.getElementById('id01').style.display='none'
  }
  openPop(){
    document.getElementById('id01').style.display='block'
  }
  
  
  
}
