package com.wallet.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.wallet.dao.TransactionRepository;
import com.wallet.dao.UserRepository;
import com.wallet.model.AmountTransaction;
import com.wallet.model.Transaction;
import com.wallet.model.User;
import com.wallet.model.UserDetails;

@Service
public class WalletServiceImpl implements WalletServiceInterface {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	//Create Account
	@Override
	public User createAccount(UserDetails u) {
		
		int c=userRepository.countByUsername(u.getUsername());
		int uId=userRepository.countByUserId(Long.parseLong(u.getUserId()));
		if(c>=1||uId>=1) {
			return null;
		}
		
		else {
		String accTime=LocalDateTime.now().toString();
		String accNum=generateAccountNumber();
		Long id=Long.parseLong(u.getUserId());
		User user=new User(id,u.getEmail(),u.getMobile(),0,accTime,u.getAccountType(),accNum,u.getUsername(),u.getPassword());
		userRepository.save(user);
		return user;
		}
		
	}
	
	//Get User Details
	@Override
	public User getUserDetails(AmountTransaction at) {
		
		int count=userRepository.countByUsernameAndPassword(at.getUsername(),at.getPassword());
		if(count!=0) {
		User user=userRepository.findByUsernameAndPassword(at.getUsername(), at.getPassword());
			return user;
		}
		else {
		return null;}
	}
	
	//get all users
	@Override
	public List<User> getAllUsers() {
		
		return userRepository.findAll();
	}
	
	//deposit amount
	@Override
	public User deposit(AmountTransaction at) {
		
		String stime=LocalDateTime.now().toString();
		String transId="TX"+stime;
		String type="Deposit";
		
		User user=userRepository.findByAccountNumber(at.getAccNumber());
		Long id=user.getUserId();
		
		double balance=user.getAccountBalance();
		balance=balance+Double.parseDouble(at.getAmount());
		String acc=userRepository.findByUsernameAndPassword(at.getUsername(), at.getPassword()).getAccountNumber();
		Transaction trans=new Transaction(id,transId,stime,type,at.getAccNumber(),acc,Double.parseDouble(at.getAmount()),balance);
		
		return saveData(user, trans);
	}
	
	//withdraw amount
	@Override
	public User withdraw(AmountTransaction at) {
		
     User   user=userRepository.findByUsernameAndPassword(at.getUsername(), at.getPassword());
		Long id=user.getUserId();
		double balance=user.getAccountBalance();
		if(balance<=Double.parseDouble(at.getAmount())) {
			return null;
		}
		
		else {
			balance=balance-Double.parseDouble(at.getAmount());
		String stime=LocalDateTime.now().toString();
		String transId="TX"+stime;
		String type="Withdraw";
		String acc=user.getAccountNumber();
		Transaction trans=new Transaction(id,transId,stime,type,acc,at.getAccNumber(),Double.parseDouble(at.getAmount()),balance);
		System.out.println(at.getAccNumber());
		
		return saveData(user, trans);
		}
	}
	
	
	
	//get transactions
	@Override
	public List<Transaction> getAllTransaction(AmountTransaction at) {
		
		int c=userRepository.countByAccountNumberAndPassword( at.getAccNumber(),at.getPassword());
		if(c==0) {
			return null;
		}
		else {
	User use=userRepository.findByAccountNumber(at.getAccNumber());
		
		List<Transaction>transactions=use.getTransactions();
	System.out.println(use);
		return transactions;
		
		}
	}
	
	//fund transfer
	@Override
	public User transferFund(AmountTransaction at) {
		User rec=new User();
		int login=userRepository.countByUsernameAndPassword(at.getUsername(), at.getPassword());
		int acount=userRepository.countByAccountNumber(at.getAccNumber());
		
		if(acount==0) {
			User incorrectAccount=new User();
			incorrectAccount.setAccountNumber("Incorrect account number");
			return incorrectAccount;
		}
		User user=withdraw(at);
		if(user==null) {
			return null;
		}
		else {
		
		 rec=deposit(at);
		}
		return userRepository.findByUsernameAndPassword(at.getUsername(), at.getPassword());
	}
	
	//check login details
	@Override
	public User loginCheck(AmountTransaction at) {
		
		int count=userRepository.countByUsernameAndPasswordAndAccountNumber(at.getUsername(), at.getPassword(), at.getAccNumber());
		if(count>0) {
		User user=userRepository.findByUsernameAndPasswordAndAccountNumber(at.getUsername(), at.getPassword(), at.getAccNumber());
			return user;
		}
		else {
		return null;}
	}
	
	//delete account
	@Override
	public User deleteAccount(AmountTransaction acc) {
		
		User user=userRepository.findByUsernameAndPassword(acc.getUsername(), acc.getPassword());
		userRepository.delete(user);
		return user;
	}
	
	//update account details
	@Override
	public User updateAccount(UserDetails u) {
		
		User user=userRepository.findByUsernameAndPassword(u.getUsername(), u.getPassword());
		user.setEmail(u.getEmail());
		user.setMobile(u.getMobile());
		user.setPassword(u.getPassword());
		userRepository.save(user);
		return user;
		
	}
	
	
	@Override
	public User saveData(User user, Transaction trans) {
		user.getTransactions().add(trans);
		user.setAccountBalance(trans.getUpdatedBalance());
		 userRepository.save(user);
		return user;
	}
	
///generate account number	
	@Override
	public String generateAccountNumber() {
		String accNum;
		String acc="ACC"+User.accNum;
		List<User> allUsers=userRepository.findAll();
		if(allUsers.size()==0) {
			accNum=acc;
		}
		else {
		List<Integer>accNumber=new ArrayList<Integer>();
		for(User u1:allUsers) {
			accNumber.add(Integer.parseInt(u1.getAccountNumber().substring(3)));
		}
		Collections.sort(accNumber,Collections.reverseOrder());
		
	 accNum="ACC"+(accNumber.get(0)+1);
		}
		return accNum;
	}
	
	}