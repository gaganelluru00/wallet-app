package com.wallet.controller;

import java.time.LocalDateTime;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wallet.dao.TransactionRepository;
import com.wallet.dao.UserRepository;
import com.wallet.exceptions.InvalidLoginException;
import com.wallet.model.AmountTransaction;
import com.wallet.model.Transaction;
import com.wallet.model.User;
import com.wallet.model.UserDetails;
import com.wallet.service.WalletServiceInterface;
import com.wallet.service.WalletServiceImpl;
import com.wallet.service.WalletServiceImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200", allowedHeaders = "*")
@RequestMapping("/transfer")
public class UserController {
	@Autowired
	WalletServiceImpl serviceImpl;
	
	
	
	

	@PostMapping("/add")
	public ResponseEntity<User> createUserAccount(@RequestBody UserDetails u) {
		return ResponseEntity.ok().body(serviceImpl.createAccount(u));
		}
	
	
	@GetMapping("/users")
	public ResponseEntity<List<User>> getUsers(){
		return ResponseEntity.ok().body(serviceImpl.getAllUsers());
	}
	
	
	
	@PutMapping("/deposit")
	public ResponseEntity<?> depositAmount(@RequestBody AmountTransaction at) {
		
		return ResponseEntity.ok().body(serviceImpl.deposit(at));
	}
	
	
	@PutMapping("/withdraw")
	public ResponseEntity<?> withdrawAmount(@RequestBody AmountTransaction at) {
		return ResponseEntity.ok().body(serviceImpl.withdraw(at));
		
	}
	
	
	@PostMapping("/print")
	public ResponseEntity<List<Transaction>> sendTransactions(@RequestBody AmountTransaction at) {
		return ResponseEntity.ok().body(serviceImpl.getAllTransaction(at));
		
		}
	
	
	@PostMapping("/fund")
	public ResponseEntity<?> fundTransfer(@RequestBody AmountTransaction at) {
		
		return ResponseEntity.ok().body(serviceImpl.transferFund(at));
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> loginValidation(@RequestBody AmountTransaction at) {
		return ResponseEntity.ok().body(serviceImpl.loginCheck(at));
	}
	
	@PutMapping("/details")
	public ResponseEntity<User> getDetails(@RequestBody AmountTransaction at) {
		
		
		return ResponseEntity.ok().body(serviceImpl.getUserDetails(at));
		}
		
	
	@GetMapping("/transactions")
	public List<Transaction>getTransactions(@RequestBody AmountTransaction at){
		return null;
	}
	
	
	@PutMapping("/delete")
	public ResponseEntity<User> deleteUser(@RequestBody AmountTransaction acc) {
		return ResponseEntity.ok().body(serviceImpl.deleteAccount(acc));
	}
	@PostMapping("/update")
	public ResponseEntity<User> updateDetails(@RequestBody UserDetails u) {
		return ResponseEntity.ok().body(serviceImpl.updateAccount(u));
	}
}
