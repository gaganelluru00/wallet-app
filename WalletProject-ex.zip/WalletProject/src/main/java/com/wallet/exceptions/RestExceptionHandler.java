package com.wallet.exceptions;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.wallet.model.User;

@ControllerAdvice
public class RestExceptionHandler {
	
	
	@ExceptionHandler(InsufficientBalanceException.class)
	public String insufficientBalance(InsufficientBalanceException ex){
		
		return ex.getMessage();
	}
	@ExceptionHandler(InvalidLoginException.class)
	public String invalidLogin(InvalidLoginException ex) {
		return ex.getMessage();
	}
	

}
