package com.wallet.exceptions;

public class InvalidLoginException extends RuntimeException {

	public InvalidLoginException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidLoginException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
